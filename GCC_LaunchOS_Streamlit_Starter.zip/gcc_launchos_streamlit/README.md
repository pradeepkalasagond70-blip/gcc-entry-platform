# GCC LaunchOS — Streamlit deployment

This repository hosts the GCC LaunchOS self-contained HTML prototype inside Streamlit.

## Files
- `app.py` — Streamlit wrapper
- `index.html` — interactive GCC LaunchOS prototype
- `requirements.txt` — Python dependency

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy on Streamlit Community Cloud
1. Push all three files to the root of a GitHub repository.
2. Sign in to Streamlit Community Cloud at https://share.streamlit.io/.
3. Select **Create app** and choose the GitHub repository and branch.
4. Set the main file path to `app.py`.
5. Click **Deploy**.

The HTML prototype is embedded in Streamlit; this does not add live API integration or a backend. Check the deployed app in a browser before sharing it.
